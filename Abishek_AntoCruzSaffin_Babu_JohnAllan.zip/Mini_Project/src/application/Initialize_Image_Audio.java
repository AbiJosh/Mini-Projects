package application;

import java.util.HashMap;
import java.util.Map;

public class Initialize_Image_Audio {
    public Map<String, String> wordToImageMap = new HashMap<>();
    public Map<String, String> wordToAudioMap = new HashMap<>();
	Initialize_Image_Audio(){
		wordToImageMap.put("APPLE", "C:\\Users\\abijo\\OneDrive\\Pictures\\Screenshots\\Screenshot 2023-12-27 194839.png");
	    wordToImageMap.put("BALL", "C:\\Users\\abijo\\OneDrive\\Pictures\\Screenshots\\Screenshot 2023-12-27 194909.png");
	    wordToImageMap.put("CAT", "C:\\Users\\abijo\\OneDrive\\Pictures\\Screenshots\\Screenshot 2023-12-29 204532.png");
	    wordToImageMap.put("DOG", "C:\\Users\\abijo\\OneDrive\\Pictures\\Screenshots\\Screenshot 2023-12-29 194728.png");
	    wordToImageMap.put("ELEPHANT", "C:\\Users\\abijo\\OneDrive\\Pictures\\Screenshots\\Screenshot 2023-12-29 194806.png");
	    wordToImageMap.put("FISH", "C:\\Users\\abijo\\OneDrive\\Pictures\\Screenshots\\Screenshot 2023-12-29 194847.png");
	    wordToImageMap.put("GOAT", "C:\\Users\\abijo\\OneDrive\\Pictures\\Screenshots\\Screenshot 2023-12-29 194919.png");
	    wordToImageMap.put("HEN", "C:\\Users\\abijo\\OneDrive\\Pictures\\Screenshots\\Screenshot 2023-12-29 195001.png");
	    wordToImageMap.put("ICE-CREAM", "C:\\Users\\abijo\\OneDrive\\Pictures\\Screenshots\\Screenshot 2023-12-29 195053.png");
	    wordToImageMap.put("JUG", "C:\\Users\\abijo\\OneDrive\\Pictures\\Screenshots\\Screenshot 2023-12-29 195201.png");
	    wordToImageMap.put("KITE", "C:\\Users\\abijo\\OneDrive\\Pictures\\Screenshots\\Screenshot 2023-12-29 195234.png");
	    wordToImageMap.put("LION", "C:\\Users\\abijo\\OneDrive\\Pictures\\Screenshots\\Screenshot 2023-12-29 195324.png");
	    wordToImageMap.put("MONKEY", "C:\\Users\\abijo\\OneDrive\\Pictures\\Screenshots\\Screenshot 2023-12-29 195503.png");
	    wordToImageMap.put("NOTEBOOK", "C:\\Users\\abijo\\OneDrive\\Pictures\\Screenshots\\Screenshot 2023-12-29 195807.png");
	    wordToImageMap.put("ORANGE", "C:\\Users\\abijo\\OneDrive\\Pictures\\Screenshots\\Screenshot 2023-12-29 195836.png");
	    wordToImageMap.put("PENGUIN", "C:\\Users\\abijo\\OneDrive\\Pictures\\Screenshots\\Screenshot 2023-12-29 204625.png");
	    wordToImageMap.put("QUESTION", "C:\\Users\\abijo\\OneDrive\\Pictures\\Screenshots\\Screenshot 2023-12-29 200413.png");
	    wordToImageMap.put("RAT", "C:\\Users\\abijo\\OneDrive\\Pictures\\Screenshots\\Screenshot 2023-12-29 200454.png");
	    wordToImageMap.put("SNAKE", "C:\\Users\\abijo\\OneDrive\\Pictures\\Screenshots\\Screenshot 2023-12-29 200545.png");
	    wordToImageMap.put("TIGER", "C:\\Users\\abijo\\OneDrive\\Pictures\\Screenshots\\Screenshot 2023-12-29 200618.png");
	    wordToImageMap.put("UMBRELLA", "C:\\Users\\abijo\\OneDrive\\Pictures\\Screenshots\\Screenshot 2023-12-29 201014.png");
	    wordToImageMap.put("VAN", "C:\\Users\\abijo\\OneDrive\\Pictures\\Screenshots\\Screenshot 2023-12-29 201108.png");
	    wordToImageMap.put("WATCH", "C:\\Users\\abijo\\OneDrive\\Pictures\\Screenshots\\Screenshot 2023-12-29 201200.png");
	    wordToImageMap.put("X-RAY", "C:\\Users\\abijo\\OneDrive\\Pictures\\Screenshots\\Screenshot 2023-12-29 201345.png");
	    wordToImageMap.put("YELLOW", "C:\\Users\\abijo\\OneDrive\\Pictures\\Screenshots\\Screenshot 2023-12-29 201410.png");
	    wordToImageMap.put("ZEBRA", "C:\\Users\\abijo\\OneDrive\\Pictures\\Screenshots\\Screenshot 2023-12-29 201448.png");
	    
	    wordToAudioMap.put("APPLE", "D:\\Projects\\Audio\\ElevenLabs_2024-01-08T13 54 36_Freya_pre_s50_sb75_m1.mp3");
        wordToAudioMap.put("BALL", "D:\\Projects\\Audio\\ElevenLabs_2024-01-08T13 54 49_Freya_pre_s50_sb75_m1.mp3");
        wordToAudioMap.put("CAT", "D:\\Projects\\Audio\\ElevenLabs_2024-01-08T13 55 00_Freya_pre_s50_sb75_m1.mp3");
        wordToAudioMap.put("DOG", "D:\\Projects\\Audio\\ElevenLabs_2024-01-08T13 55 07_Freya_pre_s50_sb75_m1.mp3");
        wordToAudioMap.put("ELEPHANT", "D:\\Projects\\Audio\\ElevenLabs_2024-01-08T13 55 18_Freya_pre_s50_sb75_m1.mp3");
        wordToAudioMap.put("FISH", "D:\\Projects\\Audio\\ElevenLabs_2024-01-08T13 55 25_Freya_pre_s50_sb75_m1.mp3");
        wordToAudioMap.put("GOAT", "D:\\Projects\\Audio\\ElevenLabs_2024-01-08T13 55 34_Freya_pre_s50_sb75_m1.mp3");
        wordToAudioMap.put("HEN", "D:\\Projects\\Audio\\ElevenLabs_2024-01-08T13 55 43_Freya_pre_s50_sb75_m1.mp3");
        wordToAudioMap.put("ICE-CREAM", "D:\\Projects\\Audio\\ElevenLabs_2024-01-08T13 55 52_Freya_pre_s50_sb75_m1.mp3");
        wordToAudioMap.put("JUG", "D:\\Projects\\Audio\\ElevenLabs_2024-01-08T13 56 02_Freya_pre_s50_sb75_m1.mp3");
        wordToAudioMap.put("KITE", "D:\\Projects\\Audio\\ElevenLabs_2024-01-08T13 56 28_Freya_pre_s50_sb75_m1.mp3");
        wordToAudioMap.put("LION", "D:\\Projects\\Audio\\ElevenLabs_2024-01-08T13 56 42_Freya_pre_s50_sb75_m1.mp3");
        wordToAudioMap.put("MONKEY", "D:\\Projects\\Audio\\ElevenLabs_2024-01-08T13 56 54_Freya_pre_s50_sb75_m1.mp3");
        wordToAudioMap.put("NOTEBOOK", "D:\\Projects\\Audio\\ElevenLabs_2024-01-08T13 57 02_Freya_pre_s50_sb75_m1.mp3");
        wordToAudioMap.put("ORANGE", "D:\\Projects\\Audio\\ElevenLabs_2024-01-08T13 57 10_Freya_pre_s50_sb75_m1.mp3");
        wordToAudioMap.put("PENGUIN", "D:\\Projects\\Audio\\ElevenLabs_2024-01-08T13 57 21_Freya_pre_s50_sb75_m1.mp3");
        wordToAudioMap.put("QUESTION", "D:\\Projects\\Audio\\ElevenLabs_2024-01-08T13 57 32_Freya_pre_s50_sb75_m1.mp3");
        wordToAudioMap.put("RAT", "D:\\Projects\\Audio\\ElevenLabs_2024-01-08T13 59 17_Freya_pre_s50_sb75_m1.mp3");
        wordToAudioMap.put("SNAKE", "D:\\Projects\\Audio\\ElevenLabs_2024-01-08T13 59 29_Freya_pre_s50_sb75_m1.mp3");
        wordToAudioMap.put("TIGER", "D:\\Projects\\Audio\\ElevenLabs_2024-01-08T13 59 39_Freya_pre_s50_sb75_m1.mp3");
        wordToAudioMap.put("UMBRELLA", "D:\\Projects\\Audio\\ElevenLabs_2024-01-08T13 59 50_Freya_pre_s50_sb75_m1.mp3");
        wordToAudioMap.put("VAN", "D:\\Projects\\Audio\\ElevenLabs_2024-01-08T14 00 02_Freya_pre_s50_sb75_m1.mp3");
        wordToAudioMap.put("WATCH", "D:\\Projects\\Audio\\ElevenLabs_2024-01-08T14 00 15_Freya_pre_s50_sb75_m1.mp3");
        wordToAudioMap.put("X-RAY", "D:\\Projects\\Audio\\ElevenLabs_2024-01-08T14 00 25_Freya_pre_s50_sb75_m1.mp3");
        wordToAudioMap.put("YELLOW", "D:\\Projects\\Audio\\ElevenLabs_2024-01-08T14 00 33_Freya_pre_s50_sb75_m1.mp3");
        wordToAudioMap.put("ZEBRA", "D:\\Projects\\Audio\\ElevenLabs_2024-01-08T14 00 43_Freya_pre_s50_sb75_m1.mp3");
	}
}
