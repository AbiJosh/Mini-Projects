package application;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

public class Word_Image_Match extends Initialize_Image_Audio{
	private String[] words = {
            "Apple", "Ball", "Cat", "Dog", "Elephant", "Fish", "Goat", "Hen", "Ice-cream", "Jug",
            "Kite", "Lion", "Monkey", "Notebook", "Orange", "Penguin", "Question", "Rat", "Snake", "Tiger",
            "Umbrella", "Van", "Watch", "X-ray", "Yellow", "Zebra"
    };
	
	public String findWordStartingWith(char startChar) {
        for (String word : words) {
            if (word.charAt(0) == startChar) {
                return word;
            }
        }
        return null;
    }

    public void displayImageForWord(String word, ImageView imageView) {
        String imagePath =wordToImageMap.get(word.toUpperCase());
        if (imagePath != null) {
            try {
                Image image = new Image(new FileInputStream(imagePath));
                imageView.setImage(image);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
    }
    public void playAudioForWord(String word) {
        String audioPath = wordToAudioMap.get(word.toUpperCase());
        if (audioPath != null) {
            Media sound = new Media(new File(audioPath).toURI().toString());
            MediaPlayer mediaPlayer = new MediaPlayer(sound);
            mediaPlayer.play();
        }
    }
}
