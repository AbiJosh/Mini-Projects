package application;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Main extends Application {

    Word_Image_Match word_image=new Word_Image_Match();
	Initialize_Image_Audio image_map=new Initialize_Image_Audio(); // Load images for specific words
	
    @Override
    public void start(Stage primaryStage) {

        BorderPane root = new BorderPane();
        VBox resultBox = new VBox(10);
        ImageView imageView = new ImageView();
        imageView.setFitHeight(150);
        imageView.setFitWidth(150);
        Label resultLabel = new Label();
        resultBox.getChildren().addAll(resultLabel, imageView);

        GridPane keypad = new GridPane();
        keypad.setHgap(10);
        keypad.setVgap(5);
        char currentChar = 'A';
        for (int row = 0; row < 7; row++) {
            for (int col = 0; col < 4; col++) {
                if (currentChar > 'Z') break;
                Button btn = new Button(String.valueOf(currentChar));
                char finalCh = currentChar;
                btn.setOnAction(e -> {
                    String userInput = String.valueOf(finalCh);
                    String word = word_image.findWordStartingWith(userInput.charAt(0));
                    if (word != null) {
                        resultLabel.setText("Word starting with '" + userInput + "': " + word);
                        word_image.displayImageForWord(word, imageView);
                        word_image.playAudioForWord(word);
                    } else {
                        resultLabel.setText("No word found starting with '" + userInput + "'. Try another character.");
                        imageView.setImage(null); // Clear the image if no word found
                    }
                });
                keypad.add(btn, col, row);
                currentChar++;
            }
        }

        root.setTop(resultBox);
        root.setCenter(keypad);
        BorderPane.setMargin(resultBox, new Insets(20));
        BorderPane.setMargin(keypad, new Insets(20));

        Scene scene = new Scene(root, 250, 450);
        primaryStage.setTitle("Alphabeez");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    

    public static void main(String[] args) {
        launch(args);
    }
}
